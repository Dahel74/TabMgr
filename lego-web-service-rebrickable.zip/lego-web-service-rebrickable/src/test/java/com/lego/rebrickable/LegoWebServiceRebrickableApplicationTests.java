package com.lego.rebrickable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegoWebServiceRebrickableApplicationTests {

	@Test
	void contextLoads() {
	}

}
