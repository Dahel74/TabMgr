package com.lego.rebrickable.model.util;

public enum PasswordType {
	EDS,
	BASE64
}
