package com.lego.rebrickable.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lego.rebrickable.configuration.LegoConfig;
import com.lego.rebrickable.exception.PartDuplicateException;
import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.lego.LegoSet;
import com.lego.rebrickable.model.rebrickable.RebrickablePart;
import com.lego.rebrickable.model.rebrickable.RebrickableSet;
import com.lego.rebrickable.model.rebrickable.RebrickableSetParts;
import com.lego.rebrickable.model.rebrickable.RebrickableSets;
import com.lego.rebrickable.service.lego.LegoService;
import com.lego.rebrickable.service.rebrickable.RebrickableService;
import com.lego.rebrickable.service.util.FileUtilService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/global")
public class GlobalController {
	@Autowired
	RebrickableService rs;
	@Autowired
	LegoService ls;
	@Autowired
	LegoConfig lc;
	@Autowired
	FileUtilService fus;

	@GetMapping("/initDB/parts/{delete}")
	public void initDBParts(@PathVariable("delete") boolean delete) {
		final List<LegoPart> llp = ls.getAllParts();
		log.info("InitDB Part : Start");
		if (!llp.isEmpty() && delete) {
			log.info("InitDB Part : Delete all parts of all owned sets");
			ls.deleteAllParts();
		}
		final List<LegoSet> rss = ls.getAllSets();
		if (!rss.isEmpty()) {
			int countSet = 1;
			for (final LegoSet lset : rss) {
				try {
					Thread.sleep(2000);
				} catch (Exception e) {
					log.error("InitDB Part : Unable to sleep", e);
				}
				log.info("InitDB Part : Get all parts for set (" + (countSet++) + "/" + rss.size() + ") number : "
						+ lset.getNumber());
				final RebrickableSetParts rsp = rs.getSetAllPart(lset.getNumber());
				int count = 1;
				for (final RebrickablePart rp : rsp.getResults()) {
					insertPart(rp, rss.size(), rsp.getResults().size(), countSet, count++, llp);
				}
			}
		}
		log.info("InitDB Part : End");
	}

	@GetMapping("/initDB/sets")
	public void initDBSets() {
		final List<LegoSet> lls = ls.getAllSets();
		log.info("InitDB Set : Start");
		if (!lls.isEmpty()) {
			log.info("InitDB Set : Delete all parts of all owned sets");
			ls.deleteAllParts();
			log.info("InitDB Set : Delete all owned sets");
			ls.deleteAllSets();
		}
		final RebrickableSets rss = rs.getAllSet();
		final List<RebrickableSet> lrs = rss.getResults();
		if (!lrs.isEmpty()) {
			for (final RebrickableSet rset : lrs) {
				log.info("InitDB Set : Insert set number : " + rset.getNumber());
				fus.createDirectory(lc.getImgPath() + "\\sets\\");
				final String name = fus.copyAndGetImagePath(rset.getImgUrl(),
						lc.getImgPath() + "\\sets\\" + rset.getNumber() + ".jpg");
				ls.insertSet(rset.toLegoSet(name));
			}
		}
		log.info("InitDB Set : End");
	}

	public void insertPart(RebrickablePart rp, int sizeSet, int sizePart, int currentSet, int currentPart,
			List<LegoPart> llp) {
		final String name = lc.getImgPath() + "\\parts\\" + rp.getNumber() + "-" + rp.getColorId() + ".jpg";
		LegoPart lp = rp.toLegoPart(name);
		if (!llp.contains(lp)) {
			log.info("InitDB Part : Insert part (" + currentPart + "/" + sizePart + ") : " + rp.getId() + " for set ("
					+ currentSet + "/" + sizeSet + ") number : " + rp.getSetNumber());
			fus.createDirectory(lc.getImgPath() + "\\parts\\");
			fus.copyAndGetImagePath(rp.getImgUrl(), name);
			try {
				ls.insertPart(lp);
			} catch (PartDuplicateException e) {
				log.error("InitDB Part : Duplicate part : " + rp.getId() + " for set : " + rp.getSetNumber(), e);
			}
		} else {
			log.info("InitDB Part : Part (" + currentPart + "/" + sizePart + ") already present in DB");
		}
	}
}
