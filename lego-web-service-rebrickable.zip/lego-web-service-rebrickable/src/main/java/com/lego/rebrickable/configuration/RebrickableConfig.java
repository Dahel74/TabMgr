package com.lego.rebrickable.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "appli.config.rebrickable")
public class RebrickableConfig {
	private String user;
	private String password;
	private String apiURL;
	private String apiKey;
}
