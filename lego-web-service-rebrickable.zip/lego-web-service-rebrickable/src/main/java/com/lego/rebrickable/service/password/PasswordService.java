package com.lego.rebrickable.service.password;

import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.util.PasswordAction;
import com.lego.rebrickable.model.util.PasswordType;

@Service
public interface PasswordService {
	public String getClearPassword(String encode);

	public String passwordTransform(String password, PasswordType type, PasswordAction action);
}
