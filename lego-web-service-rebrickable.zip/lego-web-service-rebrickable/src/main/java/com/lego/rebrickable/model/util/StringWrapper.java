package com.lego.rebrickable.model.util;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class StringWrapper {
	private String value;
}
