package com.lego.rebrickable.exception;

import org.springframework.dao.DataAccessException;

public class SetDuplicateException extends DataAccessException {
	private static final long serialVersionUID = 1L;

	public SetDuplicateException(String msg) {
		super(msg);
	}
}
