package com.lego.rebrickable.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "appli.config.global")
public class GlobalConfig {
	private String swaggerRoute;
	private boolean proxy;
}
