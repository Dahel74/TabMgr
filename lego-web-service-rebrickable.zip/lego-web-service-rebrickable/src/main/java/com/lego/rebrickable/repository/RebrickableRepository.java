package com.lego.rebrickable.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.lego.rebrickable.configuration.RebrickableConfig;
import com.lego.rebrickable.model.rebrickable.RebrickableSet;
import com.lego.rebrickable.model.rebrickable.RebrickableSetList;
import com.lego.rebrickable.model.rebrickable.RebrickableSetLists;
import com.lego.rebrickable.model.rebrickable.RebrickableSetParts;
import com.lego.rebrickable.model.rebrickable.RebrickableSets;
import com.lego.rebrickable.model.rebrickable.UserToken;
import com.lego.rebrickable.service.password.PasswordService;
import com.lego.rebrickable.service.proxy.ProxyService;

@Component
public class RebrickableRepository {
	@Autowired
	ProxyService ps;
	@Autowired
	PasswordService pwds;
	@Autowired
	RebrickableConfig rc;

	@Bean(name = "userToken")
	public UserToken currentToken() {
		return getUserToken();
	}

	public RebrickableSets getAllSet(UserToken ut) {
		final RestTemplate restTemplate = ps.getProxyRestTemplate();
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "key " + pwds.getClearPassword(rc.getApiKey()));
		final HttpEntity<String> request = new HttpEntity<>(headers);
		ResponseEntity<RebrickableSets> response = restTemplate.exchange(
				rc.getApiURL() + "users/" + ut.getUserToken() + "/sets/", HttpMethod.GET, request,
				RebrickableSets.class);
		final RebrickableSets result = response.getBody();
		while (result.getNext() != null) {
			response = restTemplate.exchange(result.getNext(), HttpMethod.GET, request, RebrickableSets.class);
			result.getResults().addAll(response.getBody().getResults());
			result.setNext(response.getBody().getNext());

		}
		return result;
	}

	public RebrickableSetLists getAllSetList(UserToken ut) {
		final RestTemplate restTemplate = ps.getProxyRestTemplate();
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "key " + pwds.getClearPassword(rc.getApiKey()));
		final HttpEntity<String> request = new HttpEntity<>(headers);
		final ResponseEntity<RebrickableSetLists> response = restTemplate.exchange(
				rc.getApiURL() + "users/" + ut.getUserToken() + "/setlists/", HttpMethod.GET, request,
				RebrickableSetLists.class);
		return response.getBody();
	}

	@Bean(name = "firstSetList")
	public RebrickableSetList getFirstSetList(UserToken ut) {
		final RebrickableSetLists list = getAllSetList(ut);
		if (!list.getResults().isEmpty()) {
			return list.getResults().get(0);
		}
		return new RebrickableSetList();
	}

	public RebrickableSet getSet(UserToken ut, String id) {
		final RestTemplate restTemplate = ps.getProxyRestTemplate();
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "key " + pwds.getClearPassword(rc.getApiKey()));
		final HttpEntity<String> request = new HttpEntity<>(headers);
		final ResponseEntity<RebrickableSet> response = restTemplate.exchange(
				rc.getApiURL() + "users/" + ut.getUserToken() + "/sets/" + id, HttpMethod.GET, request,
				RebrickableSet.class);
		return response.getBody();
	}

	public RebrickableSetParts getSetAllPart(String id) {
		final RestTemplate restTemplate = ps.getProxyRestTemplate();
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "key " + pwds.getClearPassword(rc.getApiKey()));
		final HttpEntity<String> request = new HttpEntity<>(headers);
		ResponseEntity<RebrickableSetParts> response = restTemplate.exchange(
				rc.getApiURL() + "lego/sets/" + id + "/parts/", HttpMethod.GET, request, RebrickableSetParts.class);
		final RebrickableSetParts result = response.getBody();
		while (result.getNext() != null) {
			response = restTemplate.exchange(result.getNext(), HttpMethod.GET, request, RebrickableSetParts.class);
			result.getResults().addAll(response.getBody().getResults());
			result.setNext(response.getBody().getNext());
		}
		return result;
	}

	public UserToken getUserToken() {
		final RestTemplate restTemplate = ps.getProxyRestTemplate();
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "key " + pwds.getClearPassword(rc.getApiKey()));
		final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("username", rc.getUser());
		map.add("password", pwds.getClearPassword(rc.getPassword()));
		final HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
		final ResponseEntity<UserToken> response = restTemplate.exchange(rc.getApiURL() + "users/_token/",
				HttpMethod.POST, request, UserToken.class);
		return response.getBody();
	}
}
