package com.lego.rebrickable.model.rebrickable;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RebrickableSets {
	private List<RebrickableSet> results;
	private String next;
}
