package com.lego.rebrickable.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lego.rebrickable.model.rebrickable.RebrickableSet;
import com.lego.rebrickable.model.rebrickable.RebrickableSetList;
import com.lego.rebrickable.model.rebrickable.RebrickableSetLists;
import com.lego.rebrickable.model.rebrickable.RebrickableSetParts;
import com.lego.rebrickable.model.rebrickable.RebrickableSets;
import com.lego.rebrickable.service.rebrickable.RebrickableService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/rebrickable")
public class RebrickableController {
	@Autowired
	RebrickableService rs;

	@GetMapping("/sets")
	public RebrickableSets getAllSet() {
		log.info("Get all rebrickable set");
		return rs.getAllSet();
	}

	@GetMapping("/setlist")
	public RebrickableSetList getFirstSetList() {
		log.info("Get first rebrickable setlist");
		return rs.getFirstSetList();
	}

	@GetMapping("/set/{id}")
	public RebrickableSet getSet(@PathVariable("id") String id) {
		log.info("Get a specific rebrickable set");
		return rs.getSet(id);
	}

	@GetMapping("/set/{id}/parts")
	public RebrickableSetParts getSetAllParts(@PathVariable("id") String id) {
		log.info("Get all parts for a specific set");
		return rs.getSetAllPart(id);
	}

	@GetMapping("/setlists")
	public RebrickableSetLists getSetLists() {
		log.info("Get all rebrickable setlist");
		return rs.getAllSetList();
	}
}
