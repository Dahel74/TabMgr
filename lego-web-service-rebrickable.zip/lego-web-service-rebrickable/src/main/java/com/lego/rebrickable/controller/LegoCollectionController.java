package com.lego.rebrickable.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.lego.LegoSet;
import com.lego.rebrickable.service.lego.LegoService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/lego")
public class LegoCollectionController {
	@Autowired
	LegoService ls;

	@DeleteMapping("/parts")
	public void deleteAllParts() {
		log.info("Delete all parts of all owned sets");
		ls.deleteAllParts();
	}

	@DeleteMapping("/part/{id}/set/{number}")
	public void deleteAllPartsForSet(@PathVariable("id") int id, @PathVariable("number") String number) {
		log.info("Delete a specific part of a specific owned set");
		ls.deletePart(id, number);
	}

	@DeleteMapping("/parts/set/{number}")
	public void deleteAllPartsForSet(@PathVariable("number") String number) {
		log.info("Delete all parts of a specific owned set");
		ls.deleteAllPartsForSet(number);
	}

	@DeleteMapping("/sets")
	public void deleteAllSets() {
		log.info("Delete all owned sets");
		ls.deleteAllSets();
	}

	@DeleteMapping("/set/{number}")
	public void deleteSet(@PathVariable("number") String number) {
		log.info("Delete a specific owned set");
		ls.deleteSet(number);
	}

	@GetMapping("/parts")
	public List<LegoPart> getAllParts() {
		log.info("Get all parts of all owned sets");
		return ls.getAllParts();
	}

	@GetMapping("/parts/set/{number}")
	public List<LegoPart> getAllPartsForSet(@PathVariable("number") String number) {
		log.info("Get all parts of a specific owned set");
		return ls.getAllPartsForSet(number);
	}

	@GetMapping("/sets")
	public List<LegoSet> getAllSets() {
		log.info("Get all owned sets");
		return ls.getAllSets();
	}

	@GetMapping("/part/{id}/set/{number}")
	public LegoPart getPart(@PathVariable("id") int id, @PathVariable("number") String number) {
		log.info("Get a specific part of a specific owned set");
		return ls.getPart(id, number);
	}

	@GetMapping("/set/{number}")
	public LegoSet getSet(@PathVariable("number") String number) {
		log.info("Get a specific owned set");
		return ls.getSet(number);
	}

	@PostMapping("/part")
	public void insertPart(@RequestBody LegoPart lpart) {
		log.info("Insert a specific part");
		ls.insertPart(lpart);
	}

	@PostMapping("/parts")
	public void insertPartByList(@RequestBody List<LegoPart> lparts) {
		log.info("Insert a list of parts");
		ls.insertPartByList(lparts);
	}

	@PostMapping("/set")
	public void insertSet(@RequestBody LegoSet lset) {
		log.info("Insert a specific owned set");
		ls.insertSet(lset);
	}

	@PostMapping("/sets")
	public void insertSetByList(@RequestBody List<LegoSet> lls) {
		log.info("Insert a list of specifics owned sets");
		ls.insertSetByList(lls);
	}

	@PutMapping("/part")
	public LegoPart updatePart(@RequestBody LegoPart lpart) {
		log.info("Update a specific part");
		return ls.updatePart(lpart);
	}

	@PutMapping("/set")
	public LegoSet updateSet(@RequestBody LegoSet lset) {
		log.info("Update a specific owned set");
		return ls.updateSet(lset);
	}
}
