package com.lego.rebrickable.service.rebrickable;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.rebrickable.RebrickableSet;
import com.lego.rebrickable.model.rebrickable.RebrickableSetList;
import com.lego.rebrickable.model.rebrickable.RebrickableSetLists;
import com.lego.rebrickable.model.rebrickable.RebrickableSetParts;
import com.lego.rebrickable.model.rebrickable.RebrickableSets;
import com.lego.rebrickable.model.rebrickable.UserToken;
import com.lego.rebrickable.repository.RebrickableRepository;

@Service
public class RebrickableServiceImpl implements RebrickableService {
	@Autowired
	RebrickableRepository rr;
	@Resource(name = "userToken")
	UserToken ut;

	@Override
	public RebrickableSets getAllSet() {
		return rr.getAllSet(ut);
	}

	@Override
	public RebrickableSetLists getAllSetList() {
		return rr.getAllSetList(ut);
	}

	@Override
	public RebrickableSetList getFirstSetList() {
		return rr.getFirstSetList(ut);
	}

	@Override
	public RebrickableSet getSet(String id) {
		return rr.getSet(ut, id);
	}

	@Override
	public RebrickableSetParts getSetAllPart(String id) {
		return rr.getSetAllPart(id);
	}

	@Override
	public UserToken getToken() {
		return rr.getUserToken();
	}
}
