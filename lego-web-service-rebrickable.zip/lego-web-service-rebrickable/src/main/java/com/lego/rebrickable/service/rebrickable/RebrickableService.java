package com.lego.rebrickable.service.rebrickable;

import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.rebrickable.RebrickableSet;
import com.lego.rebrickable.model.rebrickable.RebrickableSetList;
import com.lego.rebrickable.model.rebrickable.RebrickableSetLists;
import com.lego.rebrickable.model.rebrickable.RebrickableSetParts;
import com.lego.rebrickable.model.rebrickable.RebrickableSets;
import com.lego.rebrickable.model.rebrickable.UserToken;

@Service
public interface RebrickableService {
	public RebrickableSets getAllSet();

	public RebrickableSetLists getAllSetList();

	public RebrickableSetList getFirstSetList();

	public RebrickableSet getSet(String id);

	public RebrickableSetParts getSetAllPart(String id);

	public UserToken getToken();
}
