package com.lego.rebrickable.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.lego.rebrickable.exception.PartDuplicateException;
import com.lego.rebrickable.exception.PartNotFoundException;
import com.lego.rebrickable.exception.SetDuplicateException;
import com.lego.rebrickable.exception.SetNotFoundException;
import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.lego.LegoSet;

@Repository
public class LegoFactoryImpl implements LegoFactory {
	@Autowired
	@Qualifier("jdbcCustom")
	private JdbcTemplate jdbcTemplate;

	@Override
	public void deleteAllParts() {
		final String sql = "delete from parts ";
		jdbcTemplate.update(sql);
	}

	@Override
	public void deleteAllPartsForSet(String number) {
		final String sql = "delete from parts where setNumber = ? ";
		if (jdbcTemplate.update(sql, number) != 1) {
			throw new PartNotFoundException("Unable to delete : not found parts with setNumber : " + number);
		}
	}

	@Override
	public void deleteAllSets() {
		final String sql = "delete from sets ";
		jdbcTemplate.update(sql);
	}

	@Override
	public void deletePart(int id, String number) {
		final String sql = "delete from parts where id = ? and setNumber = ? ";
		if (jdbcTemplate.update(sql, id, number) != 1) {
			throw new PartNotFoundException(
					"Unable to delete : not found part : " + id + " with setNumber : " + number);
		}
	}

	@Override
	public void deleteSet(String number) {
		final String sql = "delete from sets where number = ?";
		if (jdbcTemplate.update(sql, number) != 1) {
			throw new SetNotFoundException("Unable to delete : not found set with number : " + number);
		}
	}

	@Override
	public List<LegoPart> getAllParts() {
		final String SQL = "select * from parts";
		return jdbcTemplate.query(SQL, new BeanPropertyRowMapper<LegoPart>(LegoPart.class));
	}

	@Override
	public List<LegoPart> getAllPartsForSet(String number) {
		try {
			final String sql = "select * from parts where number = ?";
			return jdbcTemplate.query(sql, new BeanPropertyRowMapper<LegoPart>(), number);
		} catch (final EmptyResultDataAccessException ex) {
			throw new PartNotFoundException("The parts with setNumber : " + number + " doesn't exist");
		}
	}

	@Override
	public List<LegoSet> getAllSets() {
		final String SQL = "select * from sets";
		return jdbcTemplate.query(SQL, new BeanPropertyRowMapper<LegoSet>(LegoSet.class));
	}

	@Override
	public LegoPart getPart(int id, String number) {
		try {
			final String sql = "select * from parts where id = ? and setNumber = ?";
			return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<LegoPart>(LegoPart.class), id, number);
		} catch (final EmptyResultDataAccessException ex) {
			throw new PartNotFoundException("The part : " + id + " with setNumber : " + number + " doesn't exist");
		}
	}

	@Override
	public LegoSet getSet(String number) {
		try {
			final String sql = "select * from sets where number = ?";
			return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<LegoSet>(LegoSet.class), number);
		} catch (final EmptyResultDataAccessException ex) {
			throw new SetNotFoundException("The set with number : " + number + " doesn't exist");
		}
	}

	@Override
	public void insertPart(LegoPart lp) {
		final String sql = "insert into parts (id, setNumber, number, name, imgPath, quantity, colorId, colorName, spare) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			jdbcTemplate.update(connection -> {
				final PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1, lp.getId());
				ps.setString(2, lp.getSetNumber());
				ps.setString(3, lp.getNumber());
				ps.setString(4, lp.getName());
				ps.setString(5, lp.getImgPath());
				ps.setInt(6, lp.getQuantity());
				ps.setInt(7, lp.getColorId());
				ps.setString(8, lp.getColorName());
				ps.setBoolean(9, lp.isSpare());
				return ps;
			});
		} catch (final DuplicateKeyException ex) {
			throw new PartDuplicateException(
					"the part : " + lp.getId() + " with setNumber : " + lp.getSetNumber() + " already exist");
		}
	}

	@Override
	public void insertPartByList(List<LegoPart> llp) {
		final String sql = "insert into parts (id, setNumber, number, name, imgPath, quantity, colorId, colorName, spare) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		jdbcTemplate.batchUpdate(sql, llp, 200, new ParameterizedPreparedStatementSetter<LegoPart>() {
			@Override
			public void setValues(PreparedStatement ps, LegoPart lp) throws SQLException {
				ps.setInt(1, lp.getId());
				ps.setString(2, lp.getSetNumber());
				ps.setString(3, lp.getNumber());
				ps.setString(4, lp.getName());
				ps.setString(5, lp.getImgPath());
				ps.setInt(6, lp.getQuantity());
				ps.setInt(7, lp.getColorId());
				ps.setString(8, lp.getColorName());
				ps.setBoolean(9, lp.isSpare());
			}
		});
	}

	@Override
	public void insertSet(LegoSet ls) {
		final String sql = "insert into sets (number, name, imgPath, numberOfPart, quantity) values (?, ?, ?, ?, ?)";
		try {
			jdbcTemplate.update(connection -> {
				final PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, ls.getNumber());
				ps.setString(2, ls.getName());
				ps.setString(3, ls.getImgPath());
				ps.setInt(4, ls.getNumberOfPart());
				ps.setInt(5, ls.getQuantity());
				return ps;
			});
		} catch (final DuplicateKeyException ex) {
			throw new SetDuplicateException("the set with number : " + ls.getNumber() + " already exist");
		}
	}

	@Override
	public void insertSetByList(List<LegoSet> lls) {
		for (final LegoSet ls : lls) {
			final String sql = "insert into sets (number, name, imgPath, numberOfPart, quantity) values (?, ?, ?, ?, ?)";
			jdbcTemplate.update(sql, ls.getNumber(), ls.getName(), ls.getImgPath(), ls.getNumberOfPart(),
					ls.getQuantity());
		}
	}

	@Override
	public LegoPart updatePart(LegoPart lp) {
		getPart(lp.getId(), lp.getSetNumber());
		final String sql = "update parts set number = ?, name = ?, imgPath = ?, quantity = ?, colorId = ?, colorName = ? where id = ? and setNumber = ?";
		jdbcTemplate.update(sql, lp.getNumber(), lp.getName(), lp.getImgPath(), lp.getQuantity(), lp.getColorId(),
				lp.getColorName(), lp.getId(), lp.getSetNumber());
		return lp;
	}

	@Override
	public LegoSet updateSet(LegoSet ls) {
		getSet(ls.getNumber());
		final String sql = "update sets set name = ?, imgPath = ?, numberOfPart = ?, quantity = ? where number = ?";
		jdbcTemplate.update(sql, ls.getName(), ls.getImgPath(), ls.getNumberOfPart(), ls.getQuantity(), ls.getNumber());
		return ls;
	}
}
