package com.lego.rebrickable.model.lego;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LegoPart {
	private int id;
	private String setNumber;
	private String number;
	private String name;
	private String imgPath;
	private int quantity;
	private int colorId;
	private String colorName;
	private boolean spare;

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		} else if (!(o instanceof LegoPart)) {
			return false;
		} else {
			LegoPart lp = (LegoPart) o;
			return lp.id == this.id && lp.setNumber.equals(this.setNumber) && lp.spare == this.spare;
		}
	}

	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + setNumber.hashCode();
		result = 31 * result + id;
		result = 31 * result + (spare ? 1 : 0);
		return result;
	}
}
