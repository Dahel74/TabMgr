package com.lego.rebrickable.service.lego;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.lego.LegoSet;

@Service
public interface LegoService {
	public void deleteAllParts();

	public void deleteAllPartsForSet(String number);

	public void deleteAllSets();

	public void deletePart(int id, String number);

	public void deleteSet(String number);

	List<LegoPart> getAllParts();

	List<LegoPart> getAllPartsForSet(String number);

	public List<LegoSet> getAllSets();

	public LegoPart getPart(int id, String number);

	public LegoSet getSet(String number);

	public void insertPart(LegoPart lp);

	public void insertPartByList(List<LegoPart> llp);

	public void insertSet(LegoSet ls);

	public void insertSetByList(List<LegoSet> lls);

	public LegoPart updatePart(LegoPart lp);

	public LegoSet updateSet(LegoSet ls);
}
