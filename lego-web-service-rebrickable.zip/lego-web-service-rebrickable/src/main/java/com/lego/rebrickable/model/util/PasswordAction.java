package com.lego.rebrickable.model.util;

public enum PasswordAction {
	ENCODE,
	DECODE
}
