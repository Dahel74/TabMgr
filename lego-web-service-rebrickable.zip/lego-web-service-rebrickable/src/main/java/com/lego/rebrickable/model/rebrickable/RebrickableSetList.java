package com.lego.rebrickable.model.rebrickable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RebrickableSetList {
	private int id;
}
