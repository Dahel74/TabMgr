package com.lego.rebrickable.service.lego;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.lego.LegoSet;
import com.lego.rebrickable.repository.LegoFactory;

@Service
public class LegoServiceImpl implements LegoService {
	@Autowired
	LegoFactory lf;

	@Override
	public void deleteAllParts() {
		lf.deleteAllParts();
	}

	@Override
	public void deleteAllPartsForSet(String number) {
		lf.deleteAllPartsForSet(number);
	}

	@Override
	public void deleteAllSets() {
		lf.deleteAllSets();
	}

	@Override
	public void deletePart(int id, String number) {
		lf.deletePart(id, number);
	}

	@Override
	public void deleteSet(String number) {
		lf.deleteSet(number);
	}

	@Override
	public List<LegoPart> getAllParts() {
		return lf.getAllParts();
	}

	@Override
	public List<LegoPart> getAllPartsForSet(String number) {
		return lf.getAllPartsForSet(number);
	}

	@Override
	public List<LegoSet> getAllSets() {
		return lf.getAllSets();
	}

	@Override
	public LegoPart getPart(int id, String number) {
		return lf.getPart(id, number);
	}

	@Override
	public LegoSet getSet(String number) {
		return lf.getSet(number);
	}

	@Override
	public void insertPart(LegoPart lp) {
		lf.insertPart(lp);
	}

	@Override
	public void insertPartByList(List<LegoPart> llp) {
		lf.insertPartByList(llp);
	}

	@Override
	public void insertSet(LegoSet ls) {
		lf.insertSet(ls);
	}

	@Override
	public void insertSetByList(List<LegoSet> lls) {
		lf.insertSetByList(lls);
	}

	@Override
	public LegoPart updatePart(LegoPart lp) {
		return lf.updatePart(lp);
	}

	@Override
	public LegoSet updateSet(LegoSet ls) {
		return lf.updateSet(ls);
	}
}
