package com.lego.rebrickable.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.lego.rebrickable.service.password.PasswordService;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "appli.config.db")
public class DBConfig {
	private String dbDriver;
	private String dbUrl;
	private String dbUsr;
	private String dbPwd;
	@Autowired
	PasswordService ps;

	@Bean(name = "dsCustom")
	public DataSource dataSource() {
		return DataSourceBuilder.create().username(getDbUsr()).password(ps.getClearPassword(getDbPwd())).url(getDbUrl())
				.driverClassName(getDbDriver()).build();
	}

	@Bean(name = "jdbcCustom")
	@Autowired
	public JdbcTemplate jdbcTemplate(@Qualifier("dsCustom") DataSource dsCustom) {
		return new JdbcTemplate(dsCustom);
	}
}
