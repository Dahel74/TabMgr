package com.lego.rebrickable.model.rebrickable.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.lego.rebrickable.model.rebrickable.RebrickableSet;

public class RebrickableSetDeserializer extends StdDeserializer<RebrickableSet> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public RebrickableSetDeserializer() {
		this(null);
	}

	protected RebrickableSetDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public RebrickableSet deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		final JsonNode rsNode = jp.getCodec().readTree(jp);
		final RebrickableSet rs = new RebrickableSet();
		rs.setQuantity(rsNode.get("quantity").intValue());
		rs.setNumber(rsNode.get("set").get("set_num").textValue());
		rs.setName(rsNode.get("set").get("name").textValue());
		rs.setImgUrl(rsNode.get("set").get("set_img_url").textValue());
		rs.setNumberOfPart(rsNode.get("set").get("num_parts").intValue());
		return rs;
	}
}
