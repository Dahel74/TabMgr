package com.lego.rebrickable.service.proxy;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public interface ProxyService {
	public RestTemplate getProxyRestTemplate();

	public boolean isProxy();
}
