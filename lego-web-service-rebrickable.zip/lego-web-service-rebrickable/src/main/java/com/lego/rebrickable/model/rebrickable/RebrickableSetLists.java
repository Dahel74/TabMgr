package com.lego.rebrickable.model.rebrickable;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RebrickableSetLists {
	private List<RebrickableSetList> results;
}
