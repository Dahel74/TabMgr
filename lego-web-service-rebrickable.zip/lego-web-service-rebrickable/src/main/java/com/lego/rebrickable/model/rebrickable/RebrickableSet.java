package com.lego.rebrickable.model.rebrickable;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.lego.rebrickable.model.lego.LegoSet;
import com.lego.rebrickable.model.rebrickable.deserializer.RebrickableSetDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonDeserialize(using = RebrickableSetDeserializer.class)
public class RebrickableSet {
	private String number;
	private String name;
	private String imgUrl;
	private int numberOfPart;
	private int quantity;

	public LegoSet toLegoSet(String name) {
		return new LegoSet(getNumber(), getName(), name, getNumberOfPart(), getQuantity());
	}
}
