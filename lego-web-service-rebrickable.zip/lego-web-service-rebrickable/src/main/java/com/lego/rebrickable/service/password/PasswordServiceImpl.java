package com.lego.rebrickable.service.password;

import java.util.Base64;

import org.springframework.stereotype.Service;

import com.lego.rebrickable.model.util.PasswordAction;
import com.lego.rebrickable.model.util.PasswordType;

@Service
public class PasswordServiceImpl implements PasswordService {
	@Override
	public String getClearPassword(String encode) {
		return passwordTransform(passwordTransform(encode, PasswordType.BASE64, PasswordAction.DECODE),
				PasswordType.EDS, PasswordAction.DECODE);
	}

	private String password64(String password, PasswordAction action) {
		switch (action) {
		case DECODE:
			return new String(Base64.getDecoder().decode(password));
		case ENCODE:
			return Base64.getEncoder().encodeToString(password.getBytes());
		default:
			break;
		}
		return "";
	}

	private String passwordEDS(String password, PasswordAction action) {
		final char[] newStr = new char[password.length()];
		int value;
		switch (action) {
		case DECODE:
			for (int i = 0; i < password.length(); i++) {
				value = password.charAt(i);
				if ((value >= 'a') && (value <= 'z')) {
					value -= 5 * (i + 1);
					if (value < 'a') {
						value = 'z' - (('z' - value) % (('z' - 'a') + 1));
					}
				}
				newStr[i] = (char) value;
			}
			return new String(newStr);
		case ENCODE:
			for (int i = 0; i < password.length(); i++) {
				value = password.charAt(i);
				if ((value >= 'a') && (value <= 'z')) {
					value += 5 * (i + 1);
					value = ((value - 'a') % (('z' - 'a') + 1)) + 'a';
				}
				newStr[i] = (char) value;
			}
			return new String(newStr);
		default:
			break;
		}
		return "";
	}

	@Override
	public String passwordTransform(String password, PasswordType type, PasswordAction action) {
		switch (type) {
		case EDS:
			return passwordEDS(password, action);
		case BASE64:
			return password64(password, action);
		default:
			break;
		}
		return "";
	}
}
