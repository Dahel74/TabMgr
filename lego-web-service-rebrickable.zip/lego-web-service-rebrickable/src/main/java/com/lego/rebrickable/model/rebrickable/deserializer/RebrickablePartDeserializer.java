package com.lego.rebrickable.model.rebrickable.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.lego.rebrickable.model.rebrickable.RebrickablePart;

public class RebrickablePartDeserializer extends StdDeserializer<RebrickablePart> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public RebrickablePartDeserializer() {
		this(null);
	}

	protected RebrickablePartDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public RebrickablePart deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
		final JsonNode rsNode = jp.getCodec().readTree(jp);
		final RebrickablePart rs = new RebrickablePart();
		rs.setSetNumber(rsNode.get("set_num").textValue());
		rs.setNumber(rsNode.get("part").get("part_num").textValue());
		rs.setName(rsNode.get("part").get("name").textValue());
		rs.setImgUrl(rsNode.get("part").get("part_img_url").textValue());
		rs.setQuantity(rsNode.get("quantity").intValue());
		rs.setColorId(rsNode.get("color").get("id").intValue());
		rs.setColorName(rsNode.get("color").get("name").textValue());
		rs.setId(rsNode.get("id").intValue());
		rs.setSpare(rsNode.get("is_spare").asBoolean());
		return rs;
	}
}
