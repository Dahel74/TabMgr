package com.lego.rebrickable.exception;

import org.springframework.dao.DataAccessException;

public class PartDuplicateException extends DataAccessException {
	private static final long serialVersionUID = 1L;

	public PartDuplicateException(String msg) {
		super(msg);
	}
}
