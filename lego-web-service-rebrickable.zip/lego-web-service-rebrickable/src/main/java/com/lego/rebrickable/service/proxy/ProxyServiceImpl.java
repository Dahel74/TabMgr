package com.lego.rebrickable.service.proxy;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthenticationInterceptor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lego.rebrickable.configuration.GlobalConfig;
import com.lego.rebrickable.configuration.ProxyConfig;
import com.lego.rebrickable.service.password.PasswordService;

@Service
public class ProxyServiceImpl implements ProxyService {
	@Autowired
	ProxyConfig pc;
	@Autowired
	GlobalConfig gc;
	@Autowired
	PasswordService ps;

	@Override
	public RestTemplate getProxyRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		if (gc.isProxy()) {
			final Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(pc.getHost(), pc.getPort()));
			final SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			requestFactory.setProxy(proxy);
			restTemplate = new RestTemplate(requestFactory);
			restTemplate.getInterceptors()
					.add(new BasicAuthenticationInterceptor(pc.getUser(), ps.getClearPassword(pc.getPassword())));
		}
		return restTemplate;
	}

	@Override
	public boolean isProxy() {
		return gc.isProxy();
	}
}
