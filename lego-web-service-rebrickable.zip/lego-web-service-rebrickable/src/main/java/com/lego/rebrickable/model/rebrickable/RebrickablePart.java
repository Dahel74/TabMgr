package com.lego.rebrickable.model.rebrickable;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.lego.rebrickable.model.lego.LegoPart;
import com.lego.rebrickable.model.rebrickable.deserializer.RebrickablePartDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonDeserialize(using = RebrickablePartDeserializer.class)
public class RebrickablePart {
	private String setNumber;
	private String number;
	private String name;
	private String imgUrl;
	private int quantity;
	private int colorId;
	private String colorName;
	private int id;
	private boolean spare;

	public LegoPart toLegoPart(String name) {
		return new LegoPart(getId(), getSetNumber(), getNumber(), getName(), name, getQuantity(), getColorId(),
				getColorName(), isSpare());
	}
}
