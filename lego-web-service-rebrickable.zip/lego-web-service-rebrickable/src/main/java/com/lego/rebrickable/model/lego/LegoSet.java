package com.lego.rebrickable.model.lego;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LegoSet {
	private String number;
	private String name;
	private String imgPath;
	private int numberOfPart;
	private int quantity;
}
