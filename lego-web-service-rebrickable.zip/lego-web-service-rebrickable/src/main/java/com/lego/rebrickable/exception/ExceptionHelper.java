package com.lego.rebrickable.exception;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class ExceptionHelper {
	@ExceptionHandler(value = { SQLIntegrityConstraintViolationException.class, SetDuplicateException.class,
			PartDuplicateException.class })
	public ResponseEntity<Object> handleDuplicateException(Exception ex) {
		log.error("Object already exist", ex.getMessage());
		return new ResponseEntity<Object>(ex.getMessage(), HttpStatus.CONFLICT);
	}

	@ExceptionHandler(value = { EmptyResultDataAccessException.class, SetNotFoundException.class,
			PartNotFoundException.class })
	public ResponseEntity<Object> handleNotFoundExcpetion(Exception ex) {
		log.error("Object Not found", ex.getMessage());
		return new ResponseEntity<Object>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
}
