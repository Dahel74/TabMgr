package com.lego.rebrickable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegoWebServiceRebrickableApplication {
	public static void main(String[] args) {
		SpringApplication.run(LegoWebServiceRebrickableApplication.class, args);
	}
}
