package com.lego.rebrickable.service.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lego.rebrickable.configuration.ProxyConfig;
import com.lego.rebrickable.service.password.PasswordService;
import com.lego.rebrickable.service.proxy.ProxyService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FileUtilService {
	@Autowired
	ProxyConfig pc;
	@Autowired
	ProxyService ps;
	@Autowired
	PasswordService pwds;

	public String copyAndGetImagePath(String url, String name) {
		if (url != null) {
			downloadFile(url, name);
		}
		return name;
	}

	public void createDirectory(String path) {
		try {
			Files.createDirectories(Paths.get(path));
		} catch (final IOException e) {
			log.error("Unable to create the directory : " + path, e);
		}
	}

	public void downloadFile(String url, String name) {
		try {
			if (!Files.exists(Paths.get(name))) {
				log.info("Copy image file from : " + url + " to " + name);
				final RestTemplate restTemplate = ps.getProxyRestTemplate();
				final HttpHeaders headers = new HttpHeaders();
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
				final HttpEntity<String> entity = new HttpEntity<>(headers);
				final ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, entity,
						byte[].class);
				Files.write(Paths.get(name), response.getBody());
			} else {
				log.info("Image file already exists : " + name);
			}
		} catch (final IOException e) {
			log.error("Unable to copy image file from : " + url + " to " + name, e);
		}
	}
}
